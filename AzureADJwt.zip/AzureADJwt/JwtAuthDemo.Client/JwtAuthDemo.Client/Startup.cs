using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;

namespace JwtAuthDemo.Client
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddHttpClient();

            services.AddControllersWithViews();

            services.AddAuthentication(options =>
            {
                options.DefaultScheme = CookieAuthenticationDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = OpenIdConnectDefaults.AuthenticationScheme;
            }).AddCookie(CookieAuthenticationDefaults.AuthenticationScheme)
            .AddOpenIdConnect(OpenIdConnectDefaults.AuthenticationScheme, options =>
            {
                //options.SignInScheme = CookieAuthenticationDefaults.AuthenticationScheme;
                //options.Authority = "https://login.microsoftonline.com/d197ac5c-5c7c-4145-a2e4-a19a8608bb67/v2.0";
                //options.ClientId = "d47d6cdb-6eb2-4557-bde4-9db8999dc944";
                //options.ClientSecret = "nL_AlP7h_-BW85UIOiWdz5-Muj_8KUxIA-";
                ////options.ResponseType = "id_token";
                //options.ResponseType = "code";
                //options.Scope.Add("api://f534a655-37b4-4028-ac28-7769d2f746f3/FullAccess");           
                //options.SaveTokens = true;  

                options.SignInScheme = CookieAuthenticationDefaults.AuthenticationScheme;
                options.Authority = "https://login.microsoftonline.com/cf4fb524-5b71-4254-8071-b7d5899e935a/v2.0";
                options.ClientId = "276c3479-0462-4d72-bbb6-c5daf4d4aaf1";
                options.ClientSecret = "0GfL0Dh_a_.rWB2zbJH3w.e_j5QSP25w~p";
                //options.ResponseType = "id_token";
                options.ResponseType = "code";
                options.Scope.Add("api://276c3479-0462-4d72-bbb6-c5daf4d4aaf1/FullAccess");
                options.SaveTokens = true;
            }
            );
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }
            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();

            app.UseAuthentication();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller=Home}/{action=Index}/{id?}");
            });
        }
    }
}
