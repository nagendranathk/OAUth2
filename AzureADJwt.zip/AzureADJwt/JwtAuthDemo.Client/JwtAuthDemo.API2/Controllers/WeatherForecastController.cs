﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.Json;
using System.Threading.Tasks;
using IdentityModel.Client;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace JwtAuthDemo.API2.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [Authorize]
    public class WeatherForecastController : ControllerBase
    {
        private static readonly string[] Summaries = new[]
        {
            "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        };

        private readonly ILogger<WeatherForecastController> _logger;
        private readonly IHttpClientFactory _httpClientFactory;
        public WeatherForecastController(ILogger<WeatherForecastController> logger,
             IHttpClientFactory httpClientFactory)
        {
            _logger = logger;
            _httpClientFactory = httpClientFactory;
        }

        public IEnumerable<WeatherForecast> Get_old()
        {
            var rng = new Random();
            return Enumerable.Range(1, 5).Select(index => new WeatherForecast
            {
                Date = DateTime.Now.AddDays(index),
                TemperatureC = rng.Next(-20, 55),
                Summary = Summaries[rng.Next(Summaries.Length)]
            })
            .ToArray();
        }

        [HttpGet]
        public async Task<string> Get()
        {
            // call the second api to get the actual weather forecasts

            var httpClient = _httpClientFactory.CreateClient();

            var currentAccessToken = await HttpContext.GetTokenAsync("access_token");
            
            var responseFromTokenEndpoint = await httpClient.RequestTokenAsync(
                new TokenRequest
                {
                    Address =
                        "https://login.microsoftonline.com/d197ac5c-5c7c-4145-a2e4-a19a8608bb67/oauth2/v2.0/token",
                    GrantType = "urn:ietf:params:oauth:grant-type:jwt-bearer",
                    ClientId = "18413101-773b-4ff4-8d9d-9c9f9bb21d63",
                    ClientSecret = "u_i6d1i0tpC_2N_9rzU2-PF3IBDJZ1I.DE",
                    Parameters =
                    {
                        { "assertion", currentAccessToken },
                        { "scope", "https://database.windows.net/.default"},
                        { "requested_token_use", "on_behalf_of"}
                    }
                });

            dynamic token = await CallDatabaseApiOnBehalfOfUser(responseFromTokenEndpoint.AccessToken);
            return token;

        }

        private static async Task<dynamic> CallDatabaseApiOnBehalfOfUser(string accessToken)
        {
            string ConnectionString = @"Data Source=nagtestdb.database.windows.net; Initial Catalog=nagtestdb";

            try
            {
                using (SqlConnection connection = new SqlConnection(ConnectionString))
                {
                    //connection.AccessToken = RetrieveTokenAsync().Result;
                    connection.AccessToken = accessToken;
                    connection.Open();
                    string sqlQuery = "Select * from dbo.WeatherForecast";
                    using (SqlCommand command = new SqlCommand(sqlQuery, connection))
                    {
                        var reader = command.ExecuteReader();
                        while (reader.Read())
                        {

                        }
                    }
                }
            }
            catch (Exception ex)
            {
            }
            return accessToken;
        }
    }
}
