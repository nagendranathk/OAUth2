﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using IdentityModel.Client;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Text.Json;

namespace JwtAuthDemo.API.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [Authorize]
    public class WeatherForecastController : ControllerBase
    {
        private static readonly string[] Summaries = new[]
        {
            "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        };

        private readonly ILogger<WeatherForecastController> _logger;
        private readonly IHttpClientFactory _httpClientFactory;

        public WeatherForecastController(ILogger<WeatherForecastController> logger,
            IHttpClientFactory httpClientFactory)
        {
            _logger = logger;
            _httpClientFactory = httpClientFactory;
        }


        public IEnumerable<WeatherForecast> Get_Old()
        {
            var rng = new Random();
            return Enumerable.Range(1, 5).Select(index => new WeatherForecast
            {
                Date = DateTime.Now.AddDays(index),
                TemperatureC = rng.Next(-20, 55),
                Summary = Summaries[rng.Next(Summaries.Length)]
            })
            .ToArray();
        }

        [HttpGet]
        public async Task<IEnumerable<WeatherForecast>> Get()
        {
            // call the second api to get the actual weather forecasts

            var httpClient = _httpClientFactory.CreateClient();

            var currentAccessToken = await HttpContext.GetTokenAsync("access_token");
            var responseFromTokenEndpoint = await httpClient.RequestTokenAsync(
                new TokenRequest
                {
                    Address =
                        "https://login.microsoftonline.com/d197ac5c-5c7c-4145-a2e4-a19a8608bb67/oauth2/v2.0/token",
                    GrantType = "urn:ietf:params:oauth:grant-type:jwt-bearer",
                    ClientId = "f534a655-37b4-4028-ac28-7769d2f746f3",
                    ClientSecret = "LYy3~2K~~RCAdgYTS~I~4w-Qf~Y-6CKVR9",
                    Parameters =
                    {
                        { "assertion", currentAccessToken },
                        { "scope", "api://18413101-773b-4ff4-8d9d-9c9f9bb21d63/FullAccess"},
                        { "requested_token_use", "on_behalf_of"}
                    }
                });

            var request = new HttpRequestMessage(
                HttpMethod.Get,
                "https://localhost:44342/weatherforecast");
            request.Headers.Authorization =
                new AuthenticationHeaderValue("Bearer", responseFromTokenEndpoint.AccessToken);

            var response = await httpClient.SendAsync(request);

            if (response.StatusCode != HttpStatusCode.OK)
            {
                // error happened
                throw new Exception(response.ReasonPhrase);
            }

            return await JsonSerializer.DeserializeAsync<IEnumerable<WeatherForecast>>(
                await response.Content.ReadAsStreamAsync());
        }
    }
}
