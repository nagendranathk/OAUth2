using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace JwtAuthDemo.API
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers();
            services.AddHttpClient();

            services.AddAuthentication("Bearer")
               .AddJwtBearer("Bearer", options =>
               {
                   //options.Authority = "https://login.microsoftonline.com/d197ac5c-5c7c-4145-a2e4-a19a8608bb67/v2.0";
                   //options.Audience = "api://f534a655-37b4-4028-ac28-7769d2f746f3";
                   //options.TokenValidationParameters.ValidIssuer= "https://sts.windows.net/cf4fb524-5b71-4254-8071-b7d5899e935a/"; 
                   options.Authority = "https://login.microsoftonline.com/cf4fb524-5b71-4254-8071-b7d5899e935a/v2.0";
                   options.Audience = "api://276c3479-0462-4d72-bbb6-c5daf4d4aaf1";
                   options.TokenValidationParameters.ValidIssuer = "https://sts.windows.net/cf4fb524-5b71-4254-8071-b7d5899e935a/";
               });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthentication();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
